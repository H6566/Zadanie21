﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Fishshop.Classes;

namespace Fishshop.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddFish.xaml
    /// </summary>
    public partial class PageAddFish : Page
    {
        private Fish _currentfish = new Fish();
        public PageAddFish(Fish selectFs)
        {
            InitializeComponent();
            if (selectFs != null)
            {
                _currentfish = selectFs;
                Titletxt.Text = "Изменение рыбы";
                btnAdd.Content = "Изменить";
            }
            DataContext = _currentfish;
        }
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentfish.Name)) error.AppendLine("Укажите название");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentfish.LifeExpectancy))) error.AppendLine("Укажите годы жизни");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentfish.Price))) error.AppendLine("Укажите цену");
            if (string.IsNullOrWhiteSpace(_currentfish.WhatDoesItEat)) error.AppendLine("Укажите питание");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentfish.id == 0)
            {
                PetShopEntities.GetContext().Fish.Add(_currentfish);
                try
                {
                    PetShopEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageFish());
                    MessageBox.Show("Новая рыба успешно добавлена!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    PetShopEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageFish());
                    MessageBox.Show("рыба успешно изменена!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageFish());
        }
    }     
    }
