﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Fishshop.Classes;
using Excel = Microsoft.Office.Interop.Excel;

namespace Fishshop.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageLvfish.xaml
    /// </summary>
    public partial class PageLvfish : Page
    {
        public PageLvfish()
        {
            InitializeComponent();
            var currentvlad = PetShopEntities.GetContext().Fish.ToList();
            DataContext = LViewFish;
            CmbFiltr.Items.Add("Все рыбы");
            foreach (var item in PetShopEntities.GetContext().Fish.
                Select(x => x.Name).Distinct().ToList())
                CmbFiltr.Items.Add(item);
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            string search = TxtSearch.Text;
            if (TxtSearch.Text != null)
            {
                LViewFish.ItemsSource = PetShopEntities.GetContext().Fish.
                    Where(x => x.Name.Contains(search)
                    || x.WhatDoesItEat.Contains(search)
                    || x.Price.ToString().Contains(search)).ToList();
            }
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            LViewFish.ItemsSource = PetShopEntities.GetContext().Fish.
                OrderBy(x => x.Name).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            LViewFish.ItemsSource = PetShopEntities.GetContext().Fish.
                OrderByDescending(x => x.Name).ToList();
        }

        private void CmbFiltr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbFiltr.SelectedValue.ToString() == "Все рыбы")
            {
                LViewFish.ItemsSource = PetShopEntities.GetContext().Fish.ToList();
                //TxbCountSearchItem.Text = dbISP19AEntities.GetContext().User.Count().ToString();
            }
            else
            {
                LViewFish.ItemsSource = PetShopEntities.GetContext().Fish.
                    Where(x => x.Name == CmbFiltr.SelectedValue.ToString()).ToList();
            }
        }

        private void BtnSaveToExcelTemplate_Click(object sender, RoutedEventArgs e)
        {
            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook wb = excelApp.Workbooks.Open($"{Directory.GetCurrentDirectory()}\\Shablon.xlsx");
            Excel.Worksheet ws = (Excel.Worksheet)wb.Worksheets[1];
            ws.Cells[1, 4] = "Аквариум";
            ws.Cells[4, 1] = "Дата";
            DateTime date = new DateTime(2022, 1, 1, 18, 30, 10);
            ws.Cells[4, 2] = date.ToShortDateString();
            int indexRows = 6;
            //ячейка
            ws.Cells[1][indexRows] = "Номер";
            ws.Cells[2][indexRows] = "Название";
            ws.Cells[3][indexRows] = "Питание";
            ws.Cells[4][indexRows] = "Цена";

            //список пользователей из таблицы после фильтрации и поиска
            var printItems = LViewFish.Items;
            //цикл по данным из списка для печати
            foreach (Fish item in printItems)
            {
                ws.Cells[1][indexRows + 1] = indexRows;
                ws.Cells[2][indexRows + 1] = item.Name;
                ws.Cells[3][indexRows + 1] = item.WhatDoesItEat;
                ws.Cells[4][indexRows + 1].Value = item.Price.ToString();

                indexRows++;
            }
            ws.Cells[indexRows + 2, 3] = "Подпись";
            ws.Cells[indexRows + 2, 4] = "Серебрянников Н.Д.";
            excelApp.Visible = true;
        }

        private void Glav_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new Glavmenu());
        }
        private void BtnSaveToExcel_Click(object sender, RoutedEventArgs e)
        {
            var app = new Excel.Application();

            //книга 
            Excel.Workbook wb = app.Workbooks.Add();
            //лист
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int indexRows = 1;
            //ячейка
            worksheet.Cells[1][indexRows] = "Номер";
            worksheet.Cells[2][indexRows] = "Название";
            worksheet.Cells[3][indexRows] = "Питание";
            worksheet.Cells[4][indexRows] = "Цена";
            //список пользователей
            var printItems = PetShopEntities.GetContext().Fish.ToList();
            //цикл по данным из таблицы
            foreach (var item in printItems)
            {
                worksheet.Cells[1][indexRows + 1] = indexRows;
                worksheet.Cells[2][indexRows + 1] = item.Name;
                worksheet.Cells[3][indexRows + 1] = item.WhatDoesItEat;
                worksheet.Cells[4][indexRows + 1] = item.Price.ToString();
                indexRows++;
            }

            //показать Excel
            app.Visible = true;
        }
    }
}
