﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Fishshop.Classes;

namespace Fishshop.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAqAdd.xaml
    /// </summary>
    public partial class PageAqAdd : Page
    {
        private Aquarium _currentaquar = new Aquarium();
        public PageAqAdd(Aquarium selectAq)
        {
            InitializeComponent();
            CMBClimate.ItemsSource = PetShopEntities.GetContext().HabitatClimate.ToList();
            CMBFish.ItemsSource = PetShopEntities.GetContext().Fish.ToList();
            CMBClimate.SelectedValuePath = "id";
            CMBClimate.DisplayMemberPath = "HabitatClimatee";
            CMBFish.SelectedValuePath = "id";
            CMBFish.DisplayMemberPath = "Name";
            if (selectAq != null)
            {
                _currentaquar = selectAq;
                Titletxt.Text = "Изменение аквариума";
                btnAdd.Content = "Изменить";
            }
            DataContext = _currentaquar;
        }
        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAquarium());
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentaquar.AquariumName)) error.AppendLine("Укажите название");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentaquar.NumberOfFish))) error.AppendLine("Укажите количество");
            if (string.IsNullOrWhiteSpace(_currentaquar.Volume)) error.AppendLine("Укажите объем");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentaquar.idHabitatClimate))) error.AppendLine("Укажите климат");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentaquar.idFish))) error.AppendLine("Укажите рыбу");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentaquar.id == 0)
            {
                PetShopEntities.GetContext().Aquarium.Add(_currentaquar);
                try
                {
                    PetShopEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageAquarium());
                    MessageBox.Show("Новый аквариум успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    PetShopEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageAquarium());
                    MessageBox.Show("аквариум успешно изменен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }
    }
}
