﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Fishshop.Classes;

namespace Fishshop.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAquarium.xaml
    /// </summary>
    public partial class PageAquarium : Page
    {
        public PageAquarium()
        {
            InitializeComponent();
            DtgSQL.ItemsSource = PetShopEntities.GetContext().Aquarium.ToList();
            CMBFilterAquar.Items.Add("От 10 до 50");
            CMBFilterAquar.Items.Add("От 51 до 100");
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DtgSQL.ItemsSource = PetShopEntities.GetContext().Aquarium.OrderBy(x => x.AquariumName).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DtgSQL.ItemsSource = PetShopEntities.GetContext().Aquarium.OrderByDescending(x => x.AquariumName).ToList();
        }

        private void FindAquar_TextChanged(object sender, TextChangedEventArgs e)
        {
            DtgSQL.ItemsSource = PetShopEntities.GetContext().Aquarium.Where(x => x.AquariumName.ToLower().Contains(FindAquar.Text.ToLower())).ToList();
        }

        private void CMBFilterAquar_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CMBFilterAquar.SelectedIndex == 0)
                DtgSQL.ItemsSource = PetShopEntities.GetContext().Aquarium.Where(x => x.NumberOfFish >= 10 && x.NumberOfFish <= 50).ToList();
            else
                DtgSQL.ItemsSource = PetShopEntities.GetContext().Aquarium.Where(x => x.NumberOfFish >= 51 && x.NumberOfFish <= 100).ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new Glavmenu());
        }

        private void BTNedit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAqAdd((Aquarium)DtgSQL.SelectedItem));
        }

        private void Delette_Click(object sender, RoutedEventArgs e)
        {
            var AquarForRemoving = DtgSQL.SelectedItems.Cast<Aquarium>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {AquarForRemoving.Count()} записи?", "Внимание",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    PetShopEntities.GetContext().Aquarium.RemoveRange(AquarForRemoving);
                    PetShopEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DtgSQL.ItemsSource = PetShopEntities.GetContext().Aquarium.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void Btnadd_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAqAdd(null));
        }
    }
}
